package Class;

public class Fooditem {
    private String foodname;
    double foodcost;
    public void setFoodname(String foodname){
        this.foodname = foodname;
    }
    public String getFoodname() {
        return foodname;
    }
    public void setFoodCost (double foodcost){
        this.foodcost = foodcost;
    }
    public double getFoodCost() {
        return foodcost;
    }

}