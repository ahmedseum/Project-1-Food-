package Class;

public class ShopList {
    public ShopList()
    {
        System.out.println("1. Sultans Dine ");
        System.out.println("2. Kacchi Vai");
        System.out.println("3. Jacksons Fried Chicken");
        System.out.println("4. Chillox");
        System.out.println("5. PizzaBurg");
    }
    public void User_Decision(int shop_number)
    {
        switch(shop_number)
        {
            case 1:
            {
                Kacchivai kacchi= new Kacchivai();
                break;
            }
            case 2:
            {
                SultansDine sultans= new SultansDine();
                break;
            }
            case 3:
            {
                Jacksons jacksons=new Jacksons();
                break;
            }
            case 4:
            {   
                Chillox chillox= new Chillox();
                break;
            }
           
            default:
            {

                break;
            }

        }
    }

}
