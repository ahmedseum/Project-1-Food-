package Class;
import java.lang.*;
public class Chillox {
     Fooditem a = new Fooditem();

     Chillox()
    {
        System.out.println("1. Pankha Wings                           - BDt:190");
        System.out.println("2. Chicken Cheese Burger                  - BDT:180");
        System.out.println("3. Fish Burger                            - BDT:250");
        System.out.println("4. Chicken Bacon Burger                   - BDT:230");
        System.out.println("5. Chicken Sausage Burger                 - BDT:240");
    }

    public void User_Food_Decision(int foodItems)
    {
        switch(foodItems)
        {
        case 1:
            {
                
                a.setFoodname("Pankha Wings");
                a.setFoodCost(190);
                
            }

        case 2: 
        {
            
            a.setFoodname("Chicken Cheese Burger");
            a.setFoodCost(180);
        }

        case 3:
        {
           
            a.setFoodname("Fish Burger");
            a.setFoodCost(250);
            
        }

       case 4: 
    {
        
        a.setFoodname("Chicken Bacon Burger");
        a.setFoodCost(230);
    }
    case 5:
    {
       
        a.setFoodname("Chicken Sausage Burger ");
        a.setFoodCost(240);
    }


        }
    }
}
