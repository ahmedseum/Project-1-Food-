package Class;
import java.lang.*;
public class PizzaBurg{
    Fooditem a = new Fooditem();

    PizzaBurg()
    {
        System.out.println("1. Cheese Fountain            - BDT:200");
        System.out.println("2. Meaty Onion                - BDT:250");
        System.out.println("3. Cheddar Cream              - BDT:276");
        System.out.println("4. Tender Beef                - BDT:290");
        System.out.println("5. Juicy Bomb                 - BDT:300");
    }

    public void User_Food_Decision(int foodItems)
    {
        switch(foodItems)
        {
            case 1:
            {

                a.setFoodname("Naga Jacks Bucket");
                a.setFoodCost(799);

            }

            case 2:
            {

                a.setFoodname("OG Jacks Bucket");
                a.setFoodCost(799);
            }

            case 3:
            {

                a.setFoodname("Sticky Jacks bucket");
                a.setFoodCost(799);

            }

            case 4:
            {

                a.setFoodname("Chicken Popcorn");
                a.setFoodCost(220);
            }
            case 5:
            {

                a.setFoodname("Tangy Jacks ");
                a.setFoodCost(220);
            }


        }
    }

}