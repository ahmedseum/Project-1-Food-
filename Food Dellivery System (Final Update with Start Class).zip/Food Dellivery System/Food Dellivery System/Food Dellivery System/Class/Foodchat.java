package Class;

import Interfaces.*;

public class Foodchat extends Fooditem implements IChart {
    Foodchat []Food_list_with_cost= new Foodchat[3];
    Foodchat []Food_name=new Foodchat[3];
    public int sum=0;
    public void addFood_name_Cost( Fooditem a)
    {
        for(int i=0;i<3;i++)
        {
            if(Food_list_with_cost[i]!=null)
            {
              a=Food_list_with_cost[i];
                break;
            }
            else{
                break;
            }
        }
    }

    public  void Show_foodList()
    {
        for(int i=0;i<3;i++)
        {
            if(Food_list_with_cost[i]!=null)
            {
                System.out.println("Food Name is : ");
                System.out.println("["+i+1+"]"+Food_list_with_cost[i].getFoodname());
            }
        }
    }
    public void add_Total_Cost() {
        for(int i=0;i<3;i++)
        {
            sum+=Food_list_with_cost[i].getFoodCost();
        }

    }
}
