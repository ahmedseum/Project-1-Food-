package Class;
import java.lang.*;
public class SultansDine {
    
    Fooditem a =new Fooditem();
    SultansDine()
    {
        System.out.println("1. Kacchi(Basmati)         - BTD:269");
        System.out.println("2. Morag Polao             - BDT:240");
        System.out.println("3. Chicken Roast           - BDT:130");
        System.out.println("4. Beef Rezala             - BDT:180");
        System.out.println("5. Chicken Tandoori        - BDT:120");
    }
    public void User_Food_Decision(int foodItems)
    {
        switch(foodItems)
        {
        case 1:
            {
                
                a.setFoodname("Kacchi(Basmati)");
                a.setFoodCost(269);
                
            }

        case 2: 
        {
            
            a.setFoodname("Morag Polao");
            a.setFoodCost(240);
        }

        case 3:
        {
           
            a.setFoodname("Chicken Roast");
            a.setFoodCost(130);
            
        }

       case 4: 
    {
        
        a.setFoodname("Beef Rezala");
        a.setFoodCost(180);
    }
    case 5:
    {
       
        a.setFoodname("Chicken Tandoori");
        a.setFoodCost(120);
    }
        }
    }
}