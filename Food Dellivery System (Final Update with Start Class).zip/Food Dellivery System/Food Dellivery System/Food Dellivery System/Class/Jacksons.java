package Class;
import java.lang.*;
public class Jacksons{
    Fooditem a = new Fooditem();

     Jacksons()
    {
        System.out.println("1. Naga Jacks Bucket            - BDt:799");
        System.out.println("2. OG Jacks Bucket              - BDT:799");
        System.out.println("3. Sticky Jacks bucket          - BDT:780");
        System.out.println("4. Chicken Popcorn              - BDT:220");
        System.out.println("5. Tangy Jacks                  - BDT:220");
    }

    public void User_Food_Decision(int foodItems)
    {
        switch(foodItems)
        {
        case 1:
            {
               
                a.setFoodname("Naga Jacks Bucket");
                a.setFoodCost(799);
                
            }

        case 2: 
        {
            
            a.setFoodname("OG Jacks Bucket");
            a.setFoodCost(799);
        }

        case 3:
        {
           
            a.setFoodname("Sticky Jacks bucket");
            a.setFoodCost(799);
            
        }

       case 4: 
    {
        
        a.setFoodname("Chicken Popcorn");
        a.setFoodCost(220);
    }
    case 5:
    {
       
        a.setFoodname("Tangy Jacks ");
        a.setFoodCost(220);
    }


        }
    }

}