 package Class;
import java.lang.*;
public class Kacchivai {
    Fooditem a = new Fooditem();
     Kacchivai()
    {
        System.out.println("1. Basmati Kacchi            - BDT:270");
        System.out.println("2. Kacchi Khadok             - BDT:430");
        System.out.println("3. Plain Polao               - BDT:150");
        System.out.println("4. Chicken Roast             - BDT:120");
        System.out.println("5. Chicken Kabab             - BDT:80");
    }

    public void User_Food_Decision(int foodItems)
    {
        switch(foodItems)
        {
        case 1:
            {
                a.setFoodname("Basmati Kcchi");
                a.setFoodCost(270);
                
            
            }

        case 2: 
        {
            a.setFoodname("Kacchi Khadok");
            a.setFoodCost(430);
            
        }

        case 3:
        {
            a.setFoodname("Plain polao");
            a.setFoodCost(150);
        
        }

       case 4: 
    {
        a.setFoodname("Chicken Roast");
        a.setFoodCost(120);
       
    }
    case 5:
    {
        a.setFoodname("Chicken Kabab");
        a.setFoodCost(430);
        
    }

        }
    }
}

