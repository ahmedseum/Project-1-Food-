package Class;

import Interfaces.ICost_and_Sum;

public class TotalCost extends Foodchat implements ICost_and_Sum {

    public void Cost()
    {
        System.out.println("Total cost is : "+sum);
    }
}
