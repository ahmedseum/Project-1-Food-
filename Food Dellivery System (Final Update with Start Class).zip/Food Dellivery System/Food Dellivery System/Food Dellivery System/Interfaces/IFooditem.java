package Interfaces;

public abstract interface IFooditem {
    public abstract void setFoodname(String foodname);
    public String getFoodname();
    public abstract void setFoodcost (double foodcost);
    public double getFoodcost ();
    }
