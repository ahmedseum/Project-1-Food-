package Interfaces;

public interface IUserInformation {
    public abstract void UserName(String name);
    public abstract void getuserLocation(String location);
    public abstract void getuserPhoneNUmber(String Phone_number);
}
