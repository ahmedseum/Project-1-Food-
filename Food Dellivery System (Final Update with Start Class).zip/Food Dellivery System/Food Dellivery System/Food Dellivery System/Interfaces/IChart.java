package Interfaces;
import Class.*;
public interface IChart {
    public abstract void add_Total_Cost();//FoodItem(class)
    public abstract void addFood_name_Cost(Fooditem a);//Food
}
