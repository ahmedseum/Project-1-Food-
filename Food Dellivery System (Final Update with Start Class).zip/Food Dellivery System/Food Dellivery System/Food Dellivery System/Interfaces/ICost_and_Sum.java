package Interfaces;

public interface ICost_and_Sum {
    public abstract void Cost();
}
